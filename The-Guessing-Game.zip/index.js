const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');
const session = require('express-session');
const crypto = require('crypto');
const ejs = require('ejs');

const app = express();
app.use(express.urlencoded({ extended: false }));

app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: crypto.randomBytes(64).toString('hex'),
  resave: false,
  saveUninitialized: true
}));

let db = new sqlite3.Database('./game.db', (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the game database.');
});

db.run(`CREATE TABLE IF NOT EXISTS players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT,
  password TEXT,
  points INTEGER,
  promotion INTEGER DEFAULT 1,
  exp INTEGER DEFAULT 0,
  points_multiplier REAL DEFAULT 1.0,
  exp_multiplier REAL DEFAULT 1.0
)`);

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

app.get('/', (req, res) => {
  res.render('index');
});

app.post('/', (req, res) => {
  let sql = `SELECT * FROM players WHERE username = ?`;
  db.get(sql, [req.body.username], (err, row) => {
    if (err) {
      return console.error(err.message);
    }
    if (row && bcrypt.compareSync(req.body.password, row.password)) {
      res.redirect(`/game/${row.id}`);
    } else {
      res.status(400).send("Invalid username or password");
    }
  });
});

app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', (req, res) => {
  let hashedPassword = bcrypt.hashSync(req.body.password, 10);
  db.run(`INSERT INTO players (username, password, points) VALUES (?, ?, 0)`, [req.body.username, hashedPassword], function(err) {
    if (err) {
      return console.log(err.message);
    }
    res.redirect('/');
  });
});

app.get('/game/:player_id', (req, res) => {
  let sql = `SELECT * FROM players WHERE id = ?`;
  db.get(sql, [req.params.player_id], (err, row) => {
    if (err) {
      return console.error(err.message);
    }
    let diceRoll = req.session.diceRoll;
    req.session.diceRoll = null;
    res.render('game', { player: row, message: diceRoll ? `The number rolled was ${diceRoll}.` : "" });
  });
});

app.post('/game/:player_id', (req, res) => {
  let sql = `SELECT * FROM players WHERE id = ?`;
  db.get(sql, [req.params.player_id], (err, row) => {
    if (err) {
      return console.error(err.message);
    }
    let newPoints = row.points;
    let diceRoll = Math.floor(Math.random() * 20) + 1;
    if (diceRoll == 10 && req.body.guess == "10") {
      newPoints *= 3; 
    } else if ((diceRoll < 10 && req.body.guess == "under 10") || (diceRoll > 10 && req.body.guess == "above 10")) {
      newPoints *= 2;  
    } else {
      newPoints *= 0.5;  
    }
    db.run(`UPDATE players SET points = ? WHERE id = ?`, [newPoints, row.id], function(err) {
      if (err) {
        return console.error(err.message);
      }
      req.session.diceRoll = diceRoll;
      res.redirect(`/game/${row.id}`);
    });
  });
});

app.get('/work/:player_id', (req, res) => {
  let sql = `SELECT * FROM players WHERE id = ?`;
  db.get(sql, [req.params.player_id], (err, row) => {
    if (err) {
      return console.error(err.message);
    }
    res.render('work', { player: row });
  });
});

app.post('/work/:player_id', (req, res) => {
  let sql = `SELECT * FROM players WHERE id = ?`;
  db.get(sql, [req.params.player_id], (err, row) => {
    if (err) {
      return console.error(err.message);
    }
    let newPoints = Math.round(row.points + row.promotion * row.points_multiplier);  
    let newExp = row.exp + row.exp_multiplier; 
    let newPromotion = row.promotion;
    if (newExp >= newPromotion) {  
      newPromotion += 1;  
      newExp = 0;  
    }
    db.run(`UPDATE players SET points = ?, exp = ?, promotion = ? WHERE id = ?`, [newPoints, newExp, newPromotion, row.id], function(err) {
      if (err) {
        return console.error(err.message);
      }
      res.redirect(`/work/${row.id}`);
    });
  });
});

app.get('/shop/:player_id', (req, res) => {
  let sql = `SELECT * FROM players WHERE id = ?`;
  db.get(sql, [req.params.player_id], (err, row) => {
    if (err) {
      return console.error(err.message);
    }
    res.render('shop', { player: row });
  });
});

app.post('/shop/:player_id', (req, res) => {
  let sql = `SELECT * FROM players WHERE id = ?`;
  db.get(sql, [req.params.player_id], (err, row) => {
    if (err) {
      return console.error(err.message);
    }
    
    let itemCost;
    let itemEffect;
    if (req.body.item === 'book') {
      itemCost = 10;
      itemEffect = { exp_multiplier: 0.1 };
    } else if (req.body.item === 'work_gloves') {
      itemCost = 100;
      itemEffect = { points_multiplier: 0.1 };
    } else if (req.body.item === 'book_shelf') {
      itemCost = 1000;
      itemEffect = { exp_multiplier: 1 };
    } else if (req.body.item === 'work_tools') {
      itemCost = 10000;
      itemEffect = { points_multiplier: 1 };
    } else if (req.body.item === 'millionaire_pass') {
      itemCost = 1000000;
      itemEffect = { points_multiplier: 1000000 };
    } else {
      // Not enough points or invalid item
      return res.redirect(`/shop/${row.id}`);
    }
    // Calculate how many of the item the player can afford
    let quantity = Math.floor(row.points / itemCost);
    if (quantity > 0) {
      row.points -= quantity * itemCost;
      for (let key in itemEffect) {
        row[key] += quantity * itemEffect[key];
      }
    } else {
      // Not enough points
      return res.redirect(`/shop/${row.id}`);
    }
    // Round the multipliers to the nearest number
    row.points_multiplier = Number(row.points_multiplier.toFixed(1));
    row.exp_multiplier = Number(row.exp_multiplier.toFixed(1));
    db.run(`UPDATE players SET points = ?, points_multiplier = ?, exp_multiplier = ? WHERE id = ?`, [row.points, row.points_multiplier, row.exp_multiplier, row.id], function(err) {
      if (err) {
        return console.error(err.message);
      }
      res.redirect(`/shop/${row.id}`);
    });
  });
});




app.get('/logout', (req, res) => {
  res.redirect('/');
});

app.listen(8080, '0.0.0.0', () => {
  console.log('Server is running on port 8080');
});
